<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>php file upload</title>
</head>
<body>

	<h1>hello</h1>

	<form action="upload.php" method="post" enctype="multipart/form-data">
		<input type="file" name="file" />
		<input type="submit" value="Upload" />
		
	</form>

</body>
</html> 