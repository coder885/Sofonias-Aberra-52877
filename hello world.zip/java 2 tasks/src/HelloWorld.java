public class HelloWorld {

    public static void main(String args[]){

        String Fname = "sofonias";
        String Lname =  "Abrra";
        int Album = 52877;

        System.out.println("Hello world. my name is "+ Fname + " "+ Lname+ " my album number is "+ Album);
    }
}
